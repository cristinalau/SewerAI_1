------------------------------------------------------------
-- Step 0: (Optional) Verify base data with your test query
-- (Adjust wonumber/tasknumber as needed)
-- Test query you posted:
-- SELECT ... FROM mnt.workordertask ... WHERE wo.wonumber = '268109' AND a.tasknumber = 1;
-- Ivara 1 "Manhole" -> Pioneer ""
-- Ivara 2 "Catch Basin" -> Pioneer ""
-- Ivara 3 "Outfall" -> Pioneer ""
-- Ivara 4 "Service Connection" -> Pioneer ""
-- Ivara 5 "Storage Unit" -> Pioneer ""
-- Ivara 6 "Inlet Outlet" -> Pioneer ""
-- Ivara 7 "Storm Water Management Facility" -> Pioneer ""
-- Ivara 8 "Pipe" -> Pioneer "Mainline"
-- Ivara 9 "Pump Station" -> Pioneer ""
-- Ivara 10 "Unknown Facility" -> Pioneer ""
-- Ivara 11"Culvert" -> Pioneer ""
-- Ivara 12"Swale" -> Pioneer ""
-- Ivara 13"Control Structure" -> Pioneer ""
-- Ivara 14"LID" -> Pioneer ""
------------------------------------------------------------

--Good query to see the data first
SELECT
    /* Work order + task info */
    wo.wonumber || '.' || a.tasknumber AS work_orders_number,
    a.wotasktitle                      AS work_order_task_title,
    s.assetnumber                      AS asset_number,
    a.longdescript                     AS work_order_task_longdesc,

    /* Facility information */
    e1.epdrdrainagefacilityoi          AS facilityoi,
    e1.facilityid                      AS facility_id,
    e1.facilitytype                    AS facility_type,

    /* PIPE TYPE */
    CASE
        WHEN e1.facilitytype = 10 THEN 'Unknown Facility'
        WHEN e1.facilitytype = 1  THEN 'Manhole'
        WHEN e1.facilitytype = 2  THEN 'Catch Basin'
        WHEN e1.facilitytype = 4  THEN 'Service Connection'
        ELSE ep1.pipetype
    END AS pip_type,

    /* FINAL PIPE_SEGMENT_REFERENCE LOGIC (priority order) */
    CASE
        WHEN mh.manholeid IS NOT NULL THEN REGEXP_REPLACE(mh.manholeid, '^MH', '')
        WHEN cb.catchbasinid IS NOT NULL THEN REGEXP_REPLACE(cb.catchbasinid, '^CB', '')
        WHEN e1.facilitytype = 10 THEN REGEXP_REPLACE(UPPER(ep2.unknfacid), '^U', '')
        WHEN esc.wass_appid IS NOT NULL THEN
            SUBSTR(esc.wass_appid, 1, INSTR(esc.wass_appid, '-', -1) - 1)
        WHEN ep1.pipeid IS NULL THEN NULL
        WHEN UPPER(ep1.pipeid) LIKE 'PIP%' THEN SUBSTR(ep1.pipeid, 4)
        WHEN UPPER(ep1.pipeid) LIKE 'CBL%' THEN SUBSTR(ep1.pipeid, 4)
        ELSE ep1.pipeid
    END AS pipe_segment_reference,

    e.epdrfacility_oi,
    e.epdrfacilityworkhistoryoi,

    /* Upstream / Downstream */
    ep1.usfacilityid       AS upstream_id,
    ep1.dsfacilityid       AS downstream_id,

    /* UUIDs */
    a.uuid                 AS work_order_task_uuid,
    e.uuid                 AS dr_uuid,
    e.createdate_dttm,
    e.lastupdate_dttm,

    /* ? UPDATED MATERIAL LOGIC (matches trigger & BASE query)
       SC (type=4): map esc.pipetype first, then fallback to mapping ep1.material
       Others: map ep1.material
    */
    CASE
        WHEN e1.facilitytype = 4 THEN
            COALESCE(mc_sc.pioneers_code, mc.pioneers_code, ep1.material)
            -- OR if you want guaranteed code: COALESCE(mc_sc.pioneers_code, mc.pioneers_code, 'XXX')
        ELSE
            NVL(mc.pioneers_code, ep1.material)
            -- OR: COALESCE(mc.pioneers_code, 'XXX')
    END AS material_code,

    /* ? Cover shape via lookup (uses ep1.shape for pipes, otherwise cb.shape); default 'Z' */
    COALESCE(sc.pioneers_code, 'Z') AS cover_shape
    -- , CASE WHEN e1.facilitytype = 8 THEN ep1.shape ELSE cb.shape END AS cover_shape_raw

FROM
    mnt.workordertask                        a
    LEFT JOIN mnt.workorders                 wo  ON a.workorder_oi = wo.workordersoi
    LEFT JOIN mnt.asset                      s   ON a.asset_oi = s.assetoi

    JOIN customerdata.epdrfacworkhistory     e   ON e.wotask_oi = a.workordertaskoi
    LEFT JOIN customerdata.epdrdrainfacility e1  ON e.epdrfacility_oi = e1.epdrdrainagefacilityoi
    LEFT JOIN customerdata.epdrpipe          ep1 ON e1.epdrpipe_oi = ep1.epdrpipeoi
    LEFT JOIN customerdata.epdrunknfac       ep2 ON e1.epdrunknownf_oi = ep2.epdrunknownfacilityoi
    LEFT JOIN customerdata."EPDRSERVICECONNECT" esc ON esc.wass_appid = e1.facilityid
    LEFT JOIN customerdata.epdrmanhole       mh  ON mh.manholeid = e1.facilityid
    LEFT JOIN customerdata.epdrcatchbasin    cb  ON cb.catchbasinid = e1.facilityid

    /* ? MATERIAL MAPPING JOIN (for ep1.material) */
    LEFT JOIN CUSTOMERDATA.EPSEWERAI_MATERIAL_CODE mc
        ON UPPER(TRIM(mc.ivara_material)) = UPPER(TRIM(ep1.material))

    /* ? MATERIAL MAPPING JOIN (for Service Connection esc.pipetype) */
    LEFT JOIN CUSTOMERDATA.EPSEWERAI_MATERIAL_CODE mc_sc
        ON UPPER(TRIM(mc_sc.ivara_material)) = UPPER(TRIM(esc.pipetype))

    /* ? NEW: SHAPE LOOKUP JOIN */
    LEFT JOIN CUSTOMERDATA.EPSEWERAI_SHAPE_CODE sc
        ON UPPER(TRIM(sc.ivara_shape)) =
           UPPER(TRIM(
               CASE
                   WHEN e1.facilitytype = 8 THEN ep1.shape
                   ELSE cb.shape
               END
           ))

WHERE
    wo.site_oi = 58
    AND e1.facilitytype IN (1, 2, 4, 8, 10)
    AND wo.wonumber = '279596'

ORDER BY
    e1.facilitytype,
    work_orders_number DESC,
    pipe_segment_reference DESC;


---------------------------------------------------------------------------------------------
-- Step 0: (Optional) Verify base data with your test query
-- (Adjust wonumber/tasknumber as needed)
-- Test query you posted:
-- SELECT ... FROM mnt.workordertask ... WHERE wo.wonumber = '268109' AND a.tasknumber = 1;
--Ivara 10 "Unknown Facility" &
--          "Unknown Facility Type" 4= "Pipe" -> Pioneer "Mainline" -> PACP
--          "Unknown Facility Type" 5= "Catch Basin Lead" -> Pioneer "Mainline" -> PACP
--          "Unknown Facility Type" 6= "Service - Sanitary" -> Pioneer "Lateral" -> PACP
--          "Unknown Facility Type" 7= "Service - Storm" -> Pioneer "Lateral" -> PACP
--          "Unknown Facility Type" 8= "Service - Water" -> Pioneer "Lateral" -> PACP
--          "Unknown Facility Type" 3= "Manhole" -> Pioneer "Maintenance Hole (Manhole)" -> MACP
--          "Unknown Facility Type" 2= "Catch Basin" -> Pioneer "Maintenance Hole (Manhole)" -> MACP

--PUT /Videos/PACP
--project_sid (work_order_task_uuid)
--inspectionid (dr_uuid)
--PO_Number (Asset_number)
--Additional_Info (work_order_task_longdesc)
--Pipe_Segment_Reference

----------------------------------------------------------------------------------------------
WITH base AS (
    SELECT
        /* Work order + task info */
        wo.wonumber || '.' || a.tasknumber           AS work_orders_number,
        a.wotasktitle                                AS work_order_task_title,
        s.assetnumber                                AS asset_number,

        /* ---- Convert HTML-encoded CLOB to clean plain text ---- */
        TRIM(
          REGEXP_REPLACE(                                  -- 6) Final trim of any leading/trailing whitespace
            REGEXP_REPLACE(                                -- 5) Collapse multiple spaces/tabs/newlines
              REGEXP_REPLACE(                              -- 4) (Optional) Remove any leftover CSS rule blocks like ".class { ... }"
                REGEXP_REPLACE(                            -- 3) Strip any remaining HTML tags
                  REGEXP_REPLACE(                          -- 2b) Remove <script>...</script> blocks (content included)
                    REGEXP_REPLACE(                        -- 2a) Remove <style>...</style> blocks (content included)
                      /* 1) Decode common HTML entities (use CHR(38) to avoid &-prompt) */
                      REPLACE(
                        REPLACE(
                          REPLACE(
                            REPLACE(
                              REPLACE(
                                REPLACE(
                                  a.longdescript,
                                  CHR(38) || 'nbsp;', ' '         -- &nbsp; ? space
                                ),
                                CHR(38) || 'lt;',   '<'           -- &lt;
                              ),
                              CHR(38) || 'gt;',   '>'             -- &gt;
                            ),
                            CHR(38) || 'quot;', '"'               -- &quot;
                          ),
                          CHR(38) || 'apos;', ''''                -- &apos;
                        ),
                        CHR(38) || 'amp;',  CHR(38)               -- &amp; (decode last)
                      ),
                      '<style[^>]*>.*?</style>',                  -- remove style blocks entirely
                      '',
                      1, 0, 'in'                                  -- i = case-insensitive, n = dot matches newline
                    ),
                    '<script[^>]*>.*?</script>',                  -- remove script blocks entirely
                    '',
                    1, 0, 'in'
                  ),
                  '<[^>]+>',                                      -- remove any residual HTML tags
                  ''
                ),
                '(\s|^)\.[A-Za-z0-9_-]+\s*\{[^}]*\}',             -- remove standalone CSS rules if any slipped through
                ' ',
                1, 0, 'n'
              ),
              '\s+',                                              -- collapse whitespace
              ' '
            ),
            '^\s+|\s+$', ''                                       -- defensive trim using regex
          )
        ) AS additional_information,

        /* Facility information */
        e1.epdrdrainagefacilityoi                    AS facilityoi,
        e1.facilityid                                AS facility_id,
        e1.facilitytype                              AS facility_type,
        e.epdrfacility_oi,
        e.epdrfacilityworkhistoryoi,
        e.createdate_dttm,
        e.lastupdate_dttm,

        /* Material selection (existing logic retained) */
        CASE
            WHEN e1.facilitytype = 4 THEN
                COALESCE(mc_sc.pioneers_code, mc.pioneers_code, ep1.material)
            ELSE
                NVL(mc.pioneers_code, ep1.material)
        END                                           AS material,

        /* ? Unified raw shape source (Pipe uses ep1.shape; otherwise CB uses cb.shape) */
        CASE
            WHEN e1.facilitytype = 8 THEN ep1.shape
            ELSE cb.shape
        END                                           AS shape_source,

        /* Access Type (raw source from CB/PIPE/UNKNOWN mapping) */
        CASE
            WHEN e1.facilitytype = 2 THEN cb.wwtype
            WHEN e1.facilitytype = 8 THEN ep1.wwtype
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN cb.wwtype
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN ep1.wwtype
            ELSE NULL
        END                                           AS access_type,

        /* PIPE TYPE */
        CASE
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 3 THEN 'Manhole'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN 'Catch Basin'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN 'Pipe'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 5 THEN 'Catch Basin Lead'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 6 THEN 'Service - Sanitary'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 7 THEN 'Service - Storm'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 8 THEN 'Service - Water'
            WHEN e1.facilitytype = 1 THEN 'Manhole'
            WHEN e1.facilitytype = 2 THEN 'Catch Basin'
            WHEN e1.facilitytype = 4 THEN 'Service Connection'
            WHEN e1.facilitytype = 8 THEN 'Pipe'
            ELSE 'Unknown Facility'
        END                                           AS pip_type,

        /* Base pipe reference */
        CASE
            WHEN e1.facilitytype = 10 THEN REGEXP_REPLACE(UPPER(ep2.unknfacid), '^U', '')
            WHEN esc.wass_appid IS NOT NULL THEN SUBSTR(esc.wass_appid, 1, INSTR(esc.wass_appid, '-', -1) - 1)
            WHEN ep1.pipeid IS NULL THEN NULL
            WHEN UPPER(ep1.pipeid) LIKE 'PIP%' THEN SUBSTR(ep1.pipeid, 4)
            WHEN UPPER(ep1.pipeid) LIKE 'CBL%' THEN SUBSTR(ep1.pipeid, 4)
            ELSE ep1.pipeid
        END                                           AS base_pipe_ref,

        /* Manhole number */
        CASE
            WHEN e1.facilitytype = 1 THEN REGEXP_REPLACE(e1.facilityid, '^MH', '')
            WHEN e1.facilitytype = 2 THEN REGEXP_REPLACE(e1.facilityid, '^CB', '')
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 3 THEN REGEXP_REPLACE(e1.facilityid, '^MH', '')
            WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN REGEXP_REPLACE(e1.facilityid, '^CB', '')
            ELSE NULL
        END                                           AS Manhole_Number,

        /* Pipe network */
        ep1.usfacilityid                              AS upstream_id,
        ep1.dsfacilityid                              AS downstream_id,

        /* UUIDs / flags */
        a.uuid                                        AS work_order_task_uuid,
        e.uuid                                        AS dr_uuid,
        ep2.unknfacType                               AS unknown_type,

        /* Inspection type */
        CASE
            WHEN e1.facilitytype IN (1, 2) THEN 'MACP'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (2, 3) THEN 'MACP'
            WHEN e1.facilitytype = 8 THEN 'PACP'
            WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (4, 5, 6, 7, 8) THEN 'PACP'
            WHEN e1.facilitytype = 4 THEN 'LACP'
            ELSE NULL
        END                                           AS inspection_type

    FROM mnt.workordertask a
    LEFT JOIN mnt.workorders wo
           ON a.workorder_oi = wo.workordersoi
    LEFT JOIN mnt.asset s
           ON a.asset_oi = s.assetoi
    JOIN customerdata.epdrfacworkhistory e
         ON e.wotask_oi = a.workordertaskoi
    LEFT JOIN customerdata.epdrdrainfacility e1
           ON e.epdrfacility_oi = e1.epdrdrainagefacilityoi
    LEFT JOIN customerdata.epdrpipe ep1
           ON e1.epdrpipe_oi = ep1.epdrpipeoi
    LEFT JOIN customerdata.epdrunknfac ep2
           ON e1.epdrunknownf_oi = ep2.epdrunknownfacilityoi

    /* EPDRSERVICECONNECT provides PIPETYPE and WASS_APPID */
    LEFT JOIN customerdata."EPDRSERVICECONNECT" esc
           ON esc.wass_appid = e1.facilityid

    LEFT JOIN customerdata.epdrcatchbasin cb
           ON cb.catchbasinid = e1.facilityid

    /* Material code maps */
    LEFT JOIN CUSTOMERDATA.EPSEWERAI_MATERIAL_CODE mc
           ON UPPER(TRIM(mc.ivara_material)) = UPPER(TRIM(ep1.material))
    LEFT JOIN CUSTOMERDATA.EPSEWERAI_MATERIAL_CODE mc_sc
           ON UPPER(TRIM(mc_sc.ivara_material)) = UPPER(TRIM(esc.pipetype))
)
SELECT
    b.work_orders_number,
    b.work_order_task_title,
    b.asset_number,
    b.additional_information,  -- now plain, CSS removed
    b.facilityoi,
    b.facility_id,
    b.facility_type,
    b.epdrfacility_oi,
    b.epdrfacilityworkhistoryoi,
    b.createdate_dttm,
    b.lastupdate_dttm,

    b.material,

    COALESCE(sc.pioneers_code, 'Z') AS cover_shape,

    CASE
        WHEN UPPER(TRIM(b.access_type)) = 'COMBINED'          THEN 'CB'
        WHEN UPPER(TRIM(b.access_type)) = 'FOUNDATION DRAIN'  THEN 'PN'
        WHEN UPPER(TRIM(b.access_type)) = 'SANITARY'          THEN 'SS'
        WHEN UPPER(TRIM(b.access_type)) = 'STORM'             THEN 'SW'
        WHEN UPPER(TRIM(b.access_type)) = 'WATER'             THEN 'XX'
        WHEN UPPER(TRIM(b.access_type)) IN ('NOT APPLICABLE','N/A','NA') THEN 'XX'
        ELSE NULL
    END AS PIPE_USE,

    b.pip_type,

    CASE
        WHEN b.facility_type IN (1, 2, 4) THEN NULL
        WHEN b.facility_type = 10 AND b.unknown_type IN (2, 3) THEN NULL
        ELSE b.base_pipe_ref
    END AS pipe_segment_reference,

    CASE
        WHEN b.facility_type = 4 THEN b.base_pipe_ref
        ELSE NULL
    END AS lateral_segment_reference,

    b.Manhole_Number,
    b.upstream_id,
    b.downstream_id,
    b.work_order_task_uuid,
    b.dr_uuid,
    b.unknown_type,
    b.inspection_type
FROM base b
LEFT JOIN CUSTOMERDATA.EPSEWERAI_SHAPE_CODE sc
    ON UPPER(TRIM(sc.ivara_shape)) = UPPER(TRIM(b.shape_source))
--WHERE b.access_type IS NOT NULL
WHERE WORK_ORDERS_NUMBER = '279596.1'
ORDER BY
    b.facility_type,
    b.work_orders_number DESC;



------------------------------------------------------------
-- Step 1: Drop table if exists (safe handling)
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE CUSTOMERDATA.EPSEWERAI_CR_INSPECT';
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Table could not be dropped: ' || SQLERRM);
END;
/
------------------------------------------------------------
-- Step 2: Create table in CUSTOMERDATA schema
--PUT /Videos/PACP
--PUT /Videos/MACP
--PUT /Videos/LACP
--project_sid (work_order_task_uuid)
--inspectionid (dr_uuid)
--PO_Number (Asset_number)
--Additional_Info (work_order_task_longdesc)
--Pipe_Segment_Reference
-- CUSTOMERDATA schema
--TRUNCATE TABLE customerdata.epsewerai_cr_inspect
--DROP TABLE customerdata.epsewerai_cr_inspect 

CREATE TABLE customerdata.epsewerai_cr_inspect (
    project_sid               RAW(16),             -- mnt.workordertask.uuid
    inspection_type           VARCHAR2(5 BYTE),    -- pacp, lacp, macp
    inspectionid              RAW(16),             -- CUSTOMERDATA.EPDRDRAINFACILITY.uuid
    workorder                 VARCHAR2(15 BYTE),   -- mnt.workorders.WONUMBER || '.' || mnt.workordertask.TaskNumber
    project                   VARCHAR2(503 BYTE),  -- mnt.workordertask.WOTASKTITLE
    po_number                 VARCHAR2(50 BYTE),   -- mnt.asset.ASSETNUMBER
    additional_information    CLOB,                -- mnt.workordertask.longdescript
    pipe_segment_reference    VARCHAR2(15 BYTE),  -- CUSTOMERDATA.EPDRDRAINFACILITY.facilityid (Strips chars as requested)
    lateral_segment_reference VARCHAR2(15 BYTE),
    manhole_number            VARCHAR2(15 BYTE),
    material                  VARCHAR2(50 BYTE),
    Pipe_Use               VARCHAR2(50 BYTE),
    cover_shape               VARCHAR2(50 BYTE),
    upstream_mh               VARCHAR2(50 BYTE),  -- CUSTOMERDATA.epdrpipe.usfacilityid 
    downstream_mh             VARCHAR2(50 BYTE),  -- CUSTOMERDATA.epdrpipe.dsfacilityid 
    feed_status               VARCHAR2(50)         -- NEW, READ
);



-- Grant INSERT privilege to MNT schema so the trigger can write to the audit table
GRANT INSERT ON CUSTOMERDATA.EPSEWERAI_CR_INSPECT TO MNT;


CREATE UNIQUE INDEX CUSTOMERDATA.UX_CR_INSPECT_INSPID
  ON CUSTOMERDATA.EPSEWERAI_CR_INSPECT(inspectionid);
  
CREATE UNIQUE INDEX CUSTOMERDATA.UX_CR_INSPECT_PROJ_INSP
  ON CUSTOMERDATA.EPSEWERAI_CR_INSPECT(project_sid, inspectionid);



-- Enable server output to see messages
SET SERVEROUTPUT ON SIZE UNLIMITED;

-- Sanity check
SELECT * FROM CUSTOMERDATA.EPSEWERAI_CR_INSPECT;
--TRUNCATE TABLE CUSTOMERDATA.EPSEWERAI_CR_INSPECT;

------------------------------------------------------------
-- Step 3: create a trigger insert into CUSTOMERDATA.EPSEWERAI_CR_INSPECT if TASK_UUID found at CUSTOMERDATA.EPSEWERAI_WOT_STG1 and FEED_STATUS  = 'SENT'.  

-- Drop old trigger (if exists)
DROP TRIGGER TRG_CR_INSPECT;
/
-- =====================================================================
-- Trigger: CUSTOMERDATA.TRG_CR_INSPECT
-- Purpose: For each new DR work-history row (EPDRFACWORKHISTORY),
--          insert exactly ONE row in EPSEWERAI_CR_INSPECT **per DR UUID**
--          (i.e., one row per inspection). No duplicates for the same DR.
--
-- Behavior (Option A):
--   � One row per DR (e.uuid). Multiple DRs for the same task will create
--     multiple CR rows (each with different inspectionid).
--   � The inserted row is created ONLY for the exact DR row being inserted,
--     guarded by e.uuid = :NEW.uuid.
--   � Dedupe guard ensures (project_sid, inspectionid) is not already present.
--
-- Notes:
--   � Includes defensive guards (WASS app id dash handling, prefix stripping).
--   � Leaves your site filter (wo.site_oi = 58) intact.
--   � Expects EPSEWERAI_CR_INSPECT.inspectionid and project_sid are RAW(16).
-- =====================================================================
CREATE OR REPLACE TRIGGER TRG_CR_INSPECT
FOR INSERT ON CUSTOMERDATA.EPDRFACWORKHISTORY
COMPOUND TRIGGER

  ------------------------------------------------------------------------
  -- Row buffer for inserted keys (one entry for each inserted DR row)
  ------------------------------------------------------------------------
  TYPE t_key IS RECORD (
    wotask_oi        NUMBER,
    epdrfacility_oi  NUMBER,
    dr_uuid          VARCHAR2(50)     -- DR UUID as text from :NEW.uuid
  );
  TYPE t_key_tab IS TABLE OF t_key;
  g_rows t_key_tab;

  ------------------------------------------------------------------------
  -- Initialize buffer
  ------------------------------------------------------------------------
  BEFORE STATEMENT IS
  BEGIN
    g_rows := t_key_tab();
  END BEFORE STATEMENT;

  ------------------------------------------------------------------------
  -- Buffer minimal keys for each inserted row
  ------------------------------------------------------------------------
  BEFORE EACH ROW IS
  BEGIN
    g_rows.EXTEND;
    g_rows(g_rows.COUNT).wotask_oi       := :NEW.wotask_oi;
    g_rows(g_rows.COUNT).epdrfacility_oi := :NEW.epdrfacility_oi;
    g_rows(g_rows.COUNT).dr_uuid         := :NEW.uuid;
  END BEFORE EACH ROW;

  ------------------------------------------------------------------------
  -- Insert one CR row per buffered DR row
  ------------------------------------------------------------------------
  AFTER STATEMENT IS
  BEGIN
    FOR i IN 1 .. g_rows.COUNT LOOP

      INSERT INTO CUSTOMERDATA.EPSEWERAI_CR_INSPECT (
        project_sid,                -- RAW(16) from a.uuid (task UUID)
        inspection_type,            -- 'PACP' | 'MACP' | 'LACP'
        inspectionid,               -- RAW(16) from e.uuid (DR UUID)
        workorder,                  -- wonumber||'.'||tasknumber (<=15)
        project,                    -- wotasktitle (<=503)
        po_number,                  -- assetnumber (<=50)
        additional_information,     -- longdescript
        pipe_segment_reference,     -- (<=15) per rules
        lateral_segment_reference,  -- (<=15) for LACP only
        manhole_number,             -- MH/CB stripped when applicable
        material,                   -- mapped code (SC: esc.pipetype -> code; else ep1.material -> code)
        Pipe_Use,                -- ? now Pioneer code (mapped from wwtype)
        cover_shape,                -- mapped via EPSEWERAI_SHAPE_CODE, default 'Z'
        upstream_mh,                -- ep1.usfacilityid (<=15)
        downstream_mh,              -- ep1.dsfacilityid (<=15)
        feed_status                 -- 'NEW'
      )
      SELECT
        /* project_sid (task UUID -> RAW(16)) */
        HEXTORAW(REPLACE(a.uuid, '-', '')),

        /* inspection_type */
        CASE
          WHEN e1.facilitytype IN (1, 2) THEN 'MACP'
          WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (2, 3) THEN 'MACP'
          WHEN e1.facilitytype = 8 THEN 'PACP'
          WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (4, 5, 6, 7, 8) THEN 'PACP'
          WHEN e1.facilitytype = 4 THEN 'LACP'
          ELSE NULL
        END,

        /* inspectionid (DR UUID -> RAW(16)) */
        HEXTORAW(REPLACE(e.uuid, '-', '')),

        /* workorder (<=15) */
        SUBSTR(wo.wonumber || '.' || a.tasknumber, 1, 15),

        /* project (<=503) */
        SUBSTR(a.wotasktitle, 1, 503),

        /* po_number (<=50) */
        SUBSTR(s.assetnumber, 1, 50),

        /* additional_information */
        a.longdescript,

        /* pipe_segment_reference (<=15) - NULL for MH/CB/LACP & unknown mapped to MH/CB */
        CASE
          WHEN e1.facilitytype IN (1, 2, 4) THEN NULL
          WHEN e1.facilitytype = 10 AND ep2.unknfacType IN (2, 3) THEN NULL
          ELSE SUBSTR(
                 CASE
                   WHEN e1.facilitytype = 10
                     THEN REGEXP_REPLACE(UPPER(ep2.unknfacid), '^U', '')
                   WHEN esc.wass_appid IS NOT NULL AND INSTR(esc.wass_appid, '-', -1) > 0
                     THEN SUBSTR(esc.wass_appid, 1, INSTR(esc.wass_appid, '-', -1) - 1)
                   WHEN ep1.pipeid IS NULL
                     THEN NULL
                   WHEN UPPER(ep1.pipeid) LIKE 'PIP%' THEN SUBSTR(ep1.pipeid, 4)
                   WHEN UPPER(ep1.pipeid) LIKE 'CBL%' THEN SUBSTR(ep1.pipeid, 4)
                   ELSE ep1.pipeid
                 END, 1, 15)
        END,

        /* lateral_segment_reference (only for LACP / facilitytype=4) */
        CASE
          WHEN e1.facilitytype = 4 THEN
            SUBSTR(
              CASE
                WHEN e1.facilitytype = 10
                  THEN REGEXP_REPLACE(UPPER(ep2.unknfacid), '^U', '')
                WHEN esc.wass_appid IS NOT NULL AND INSTR(esc.wass_appid, '-', -1) > 0
                  THEN SUBSTR(esc.wass_appid, 1, INSTR(esc.wass_appid, '-', -1) - 1)
                WHEN ep1.pipeid IS NULL
                  THEN NULL
                WHEN UPPER(ep1.pipeid) LIKE 'PIP%' THEN SUBSTR(ep1.pipeid, 4)
                WHEN UPPER(ep1.pipeid) LIKE 'CBL%' THEN SUBSTR(ep1.pipeid, 4)
                ELSE ep1.pipeid
              END, 1, 15)
          ELSE NULL
        END,

        /* manhole_number (strip MH/CB) */
        CASE
          WHEN e1.facilitytype = 1 THEN REGEXP_REPLACE(UPPER(e1.facilityid), '^MH', '')
          WHEN e1.facilitytype = 2 THEN REGEXP_REPLACE(UPPER(e1.facilityid), '^CB', '')
          WHEN e1.facilitytype = 10 AND ep2.unknfacType = 3 THEN REGEXP_REPLACE(UPPER(e1.facilityid), '^MH', '')
          WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN REGEXP_REPLACE(UPPER(e1.facilityid), '^CB', '')
          ELSE NULL
        END,

        /* material:
           - If Service Connection (type=4): map esc.pipetype (mx_sc), fallback -> mapped ep1.material (mx), fallback -> raw ep1.material
           - Else: mapped ep1.material (mx) -> raw ep1.material
        */
        CASE
          WHEN e1.facilitytype = 4 THEN
            COALESCE(mx_sc.pioneers_code, mx.pioneers_code, ep1.material)
          ELSE
            NVL(mx.pioneers_code, ep1.material)
        END,

        /* Pipe_Use -> Pioneer code (from wwtype) */
        CASE
          WHEN UPPER(TRIM(
                 CASE
                   WHEN e1.facilitytype = 2  THEN cb.wwtype
                   WHEN e1.facilitytype = 8  THEN ep1.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN cb.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN ep1.wwtype
                   ELSE NULL
                 END
               )) = 'COMBINED'          THEN 'CB'
          WHEN UPPER(TRIM(
                 CASE
                   WHEN e1.facilitytype = 2  THEN cb.wwtype
                   WHEN e1.facilitytype = 8  THEN ep1.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN cb.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN ep1.wwtype
                   ELSE NULL
                 END
               )) = 'FOUNDATION DRAIN'  THEN 'PN'
          WHEN UPPER(TRIM(
                 CASE
                   WHEN e1.facilitytype = 2  THEN cb.wwtype
                   WHEN e1.facilitytype = 8  THEN ep1.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN cb.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN ep1.wwtype
                   ELSE NULL
                 END
               )) = 'SANITARY'          THEN 'SS'
          WHEN UPPER(TRIM(
                 CASE
                   WHEN e1.facilitytype = 2  THEN cb.wwtype
                   WHEN e1.facilitytype = 8  THEN ep1.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN cb.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN ep1.wwtype
                   ELSE NULL
                 END
               )) = 'STORM'             THEN 'SW'
          WHEN UPPER(TRIM(
                 CASE
                   WHEN e1.facilitytype = 2  THEN cb.wwtype
                   WHEN e1.facilitytype = 8  THEN ep1.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 2 THEN cb.wwtype
                   WHEN e1.facilitytype = 10 AND ep2.unknfacType = 4 THEN ep1.wwtype
                   ELSE NULL
                 END
               )) IN ('WATER', 'NOT APPLICABLE', 'N/A', 'NA') THEN 'XX'
          ELSE NULL
        END,

        /* cover_shape via lookup (default 'Z') */
        COALESCE(sc.pioneers_code, 'Z') AS cover_shape,

        /* upstream/downstream (<=15) */
        SUBSTR(ep1.usfacilityid, 1, 15),
        SUBSTR(ep1.dsfacilityid, 1, 15),

        /* feed_status */
        'NEW'
      FROM mnt.workordertask                    a
      JOIN customerdata.epdrfacworkhistory      e   ON e.wotask_oi = a.workordertaskoi
      LEFT JOIN mnt.workorders                  wo  ON a.workorder_oi = wo.workordersoi
      LEFT JOIN mnt.asset                       s   ON a.asset_oi = s.assetoi
      LEFT JOIN customerdata.epdrdrainfacility  e1  ON e.epdrfacility_oi = e1.epdrdrainagefacilityoi
      LEFT JOIN customerdata.epdrpipe           ep1 ON e1.epdrpipe_oi = ep1.epdrpipeoi
      LEFT JOIN customerdata.epdrunknfac        ep2 ON e1.epdrunknownf_oi = ep2.epdrunknownfacilityoi
      LEFT JOIN customerdata."EPDRSERVICECONNECT" esc ON esc.wass_appid = e1.facilityid
      LEFT JOIN customerdata.epdrcatchbasin     cb  ON cb.catchbasinid = e1.facilityid

      /* Mapping joins */
      LEFT JOIN CUSTOMERDATA.EPSEWERAI_MATERIAL_CODE mx
        ON UPPER(TRIM(mx.ivara_material)) = UPPER(TRIM(ep1.material))
      LEFT JOIN CUSTOMERDATA.EPSEWERAI_MATERIAL_CODE mx_sc
        ON UPPER(TRIM(mx_sc.ivara_material)) = UPPER(TRIM(esc.pipetype))

      /* Shape lookup join � uses ep1.shape for pipes, otherwise cb.shape */
      LEFT JOIN CUSTOMERDATA.EPSEWERAI_SHAPE_CODE sc
        ON UPPER(TRIM(sc.ivara_shape)) =
           UPPER(TRIM(
             CASE
               WHEN e1.facilitytype = 8 THEN ep1.shape
               ELSE cb.shape
             END
           ))

      WHERE wo.site_oi        = 58
        AND e.wotask_oi       = g_rows(i).wotask_oi
        AND e.epdrfacility_oi = g_rows(i).epdrfacility_oi
        -- Only the just-inserted DR row
        AND e.uuid            = g_rows(i).dr_uuid
        -- De-dupe: prevent same (project_sid, inspectionid) from being inserted twice
        AND NOT EXISTS (
              SELECT 1
              FROM CUSTOMERDATA.EPSEWERAI_CR_INSPECT t
              WHERE t.project_sid  = HEXTORAW(REPLACE(a.uuid, '-', ''))
                AND t.inspectionid = HEXTORAW(REPLACE(e.uuid, '-', ''))
            );

    END LOOP;
  END AFTER STATEMENT;

END TRG_CR_INSPECT;
/

ALTER TRIGGER TRG_CR_INSPECT ENABLE;
/


-- Sanity check
SELECT * FROM CUSTOMERDATA.EPSEWERAI_CR_INSPECT;

CREATE OR REPLACE FORCE EDITIONABLE VIEW "CUSTOMERDATA"."V_CR_INSPECT_TO_SEND" (
  "PROJECT_SID",
  "INSPECTION_TYPE",
  "INSPECTIONID",
  "WORKORDER",
  "PROJECT",
  "PO_NUMBER",
  "ADDITIONAL_INFORMATION",
  "PIPE_SEGMENT_REFERENCE",
  "LATERAL_SEGMENT_REFERENCE",
  "MANHOLE_NUMBER",
  "MATERIAL",
  "PIPE_USE",
  "COVER_SHAPE",
  "UPSTREAM_MH",
  "DOWNSTREAM_MH",
  "FEED_STATUS"
) AS
SELECT
  LOWER(
    REGEXP_REPLACE(
      RAWTOHEX(c.PROJECT_SID),
      '^(........)(....)(....)(....)(............)$',
      '\1-\2-\3-\4-\5'
    )
  )                           AS "PROJECT_SID",
  c."INSPECTION_TYPE",
  LOWER(
    REGEXP_REPLACE(
      RAWTOHEX(c.INSPECTIONID),
      '^(........)(....)(....)(....)(............)$',
      '\1-\2-\3-\4-\5'
    )
  )                           AS "INSPECTIONID",
  c."WORKORDER",
  c."PROJECT",
  c."PO_NUMBER",

  /* ---- Robust HTML decode + strip (handles single AND double encoding) ---- */
  CAST(
    TRIM(
      REGEXP_REPLACE(                                        -- 6) Final defensive trim (regex)
        REGEXP_REPLACE(                                      -- 5) Collapse whitespace
          REGEXP_REPLACE(                                    -- 4) Strip any remaining HTML tags (after decoding)
            REGEXP_REPLACE(                                  -- 3b) Remove <script>...</script> (dot matches newline)
              REGEXP_REPLACE(                                -- 3a) Remove <style>...</style> (dot matches newline)
                /* 2) Decode to REAL characters (handle double-encoded first, then single-encoded) */
                REPLACE(                                     -- 2f) &amp; -> &
                  REPLACE(                                   -- 2e) apos
                    REPLACE(                                 -- 2d) quot
                      REPLACE(                               -- 2c) gt
                        REPLACE(                             -- 2b) lt
                          REPLACE(                           -- 2a) nbsp
                            REPLACE(                         -- 1f) &amp;nbsp; -> &nbsp;
                              REPLACE(
                                REPLACE(
                                  REPLACE(
                                    REPLACE(
                                      REPLACE(
                                        REPLACE(
                                          c."ADDITIONAL_INFORMATION",
                                          CHR(38) || 'nbsp;', ' '     -- &nbsp; -> space (single-encoded)
                                        ),
                                        CHR(38) || 'lt;',   '<'       -- &lt;   -> <
                                      ),
                                      CHR(38) || 'gt;',   '>'         -- &gt;   -> >
                                    ),
                                    CHR(38) || 'quot;', '"'           -- &quot; -> "
                                  ),
                                  CHR(38) || 'apos;', ''''            -- &apos; -> '
                                ),
                                CHR(38) || 'amp;nbsp;', CHR(38) || 'nbsp;'  -- &amp;nbsp; -> &nbsp; (normalize)
                              ),
                              CHR(38) || 'amp;lt;', CHR(38) || 'lt;'        -- &amp;lt; -> &lt;
                            ),
                            CHR(38) || 'amp;gt;', CHR(38) || 'gt;'          -- &amp;gt; -> &gt;
                          ),
                          CHR(38) || 'amp;quot;', CHR(38) || 'quot;'        -- &amp;quot; -> &quot;
                        ),
                        CHR(38) || 'amp;apos;', CHR(38) || 'apos;'          -- &amp;apos; -> &apos;
                      ),
                      CHR(38) || 'quot;', '"'                               -- ensure any stray &quot; -> "
                    ),
                    CHR(38) || 'apos;', ''''                                -- ensure any stray &apos; -> '
                  ),
                  CHR(38) || 'amp;',  CHR(38)                               -- decode &amp; last -> &
                ),
                '<style[^>]*>.*?</style>',                -- remove real <style> blocks
                '',
                1, 0, 'in'
              ),
              '<script[^>]*>.*?</script>',               -- remove real <script> blocks
              '',
              1, 0, 'in'
            ),
            '<[^>]+>',                                    -- strip any remaining tags (doctype, html, head, body, p, span, etc.)
            '',
            1, 0, 'n'
          ),
          '\s+',                                          -- collapse whitespace
          ' '
        ),
        '^\s+|\s+$', ''                                   -- final trim
      )
    ) AS VARCHAR2(4000)
  )                           AS "ADDITIONAL_INFORMATION",

  c."PIPE_SEGMENT_REFERENCE",
  c."LATERAL_SEGMENT_REFERENCE",
  c."MANHOLE_NUMBER",
  c."MATERIAL",
  c.PIPE_USE                  AS "PIPE_USE",
  c."COVER_SHAPE",
  c."UPSTREAM_MH",
  c."DOWNSTREAM_MH",
  c."FEED_STATUS"
FROM CUSTOMERDATA.EPSEWERAI_CR_INSPECT c
WHERE UPPER(TRIM(c.FEED_STATUS)) = 'NEW'
  AND EXISTS (
    SELECT 1
    FROM CUSTOMERDATA.EPSEWERAI_WOT_STG1 w
    WHERE UPPER(TRIM(w.FEED_STATUS)) = 'SENT'
      AND REPLACE(UPPER(TRIM(w.TASK_UUID)), '-', '') = RAWTOHEX(c.PROJECT_SID)
      AND c.inspection_type IS NOT NULL
  );
  

select * from CUSTOMERDATA.V_CR_INSPECT_TO_SEND;

select count(*) from CUSTOMERDATA.V_CR_INSPECT_TO_SEND;
SELECT USER FROM dual;
